package com.guluuniversity.patience.jumiaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class secondActivity : AppCompatActivity() {
    private val webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val webView = findViewById<WebView>(R.id.website)
        webView?.webViewClient = WebViewClient()
        webView?.loadUrl("https://www.jumia.ug/")
        val webSettings = webView?.settings
        webSettings?.javaScriptEnabled = true
    }

    override fun onBackPressed() {
        if (webView!!.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}